import { yomama } from "./yomama";
console.log(yomama("fine"));