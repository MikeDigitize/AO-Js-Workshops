var yomama = require("./yomama");
console.log(yomama("fat"));