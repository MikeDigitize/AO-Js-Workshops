module.exports = function(desc) {
	return "Yo' moma's so " + desc;
};